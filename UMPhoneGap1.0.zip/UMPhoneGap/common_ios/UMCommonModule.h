//
//  UMCommonModule.h
//  PhoneGap_Component
//
//  Created by wangfei on 2017/10/11.
//

#import <Foundation/Foundation.h>
#import <UMCommon/UMCommon.h>
@interface UMCommonModule : NSObject
+ (void)initWithAppkey:(NSString *)appkey channel:(NSString *)channel;
@end
